from flask import Flask, request, render_template, send_file
import torch
import pickle
import os
import cv2
import numpy as np
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
import tempfile

# Define the Flask app
app = Flask(__name__)

# Load the pickled YOLOv8 and ResNet50 models
model_file_path = 'file_path'
with open(model_file_path, 'rb') as file:
    models = pickle.load(file)

model_yolo = models['yolo']
resnet = models['resnet']

# Define image transformation
transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

# Define a route for the main page where users can upload an image
@app.route('/')
def upload_page():
    return '''
    <!doctype html>
    <title>Product Detection and Grouping</title>
    <h1>Upload an Image for Product Classification</h1>
    <form method="POST" action="/classify" enctype="multipart/form-data">
      <input type="file" name="file" accept="image/*">
      <input type="submit" value="Upload and Classify">
    </form>
    '''

# Define a route to handle image upload and classification
@app.route('/classify', methods=['POST'])
def classify_image():
    if 'file' not in request.files:
        return 'No file part', 400
    
    file = request.files['file']
    if file.filename == '':
        return 'No selected file', 400
    
    if file:
        # Save the uploaded image to a temporary file
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.jpg')
        file.save(temp_file.name)

        # Load the image
        image_path = temp_file.name
        image = cv2.imread(image_path)
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # Detect products using YOLOv8
        results = model_yolo.predict(image_path)
        boxes = results[0].boxes.xyxy.cpu().numpy()  # Extract bounding boxes

        # Extract features from each detected product and store them
        features = []
        for box in boxes:
            x1, y1, x2, y2 = map(int, box)
            product_region = image_rgb[y1:y2, x1:x2]
            product_features = extract_features(product_region, resnet)
            features.append(product_features)

        # Perform PCA for dimensionality reduction (using pre-trained ResNet)
        from sklearn.decomposition import PCA
        from sklearn.cluster import KMeans

        pca = PCA(n_components=20)  # Reduce features to 20 dimensions
        reduced_features = pca.fit_transform(features)

        # Perform K-means clustering on the features
        n_clusters = 5  # Set the number of clusters
        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        kmeans.fit(reduced_features)
        labels = kmeans.labels_

        # Plot clustered products with different colors
        for idx, box in enumerate(boxes):
            x1, y1, x2, y2 = map(int, box)
            label = labels[idx]
            color = (int(label * 50 % 255), int(label * 100 % 255), int(label * 150 % 255))
            cv2.rectangle(image_rgb, (x1, y1), (x2, y2), color, 3)

        # Save and return the clustered image
        output_path = tempfile.NamedTemporaryFile(delete=False, suffix='.png').name
        plt.imsave(output_path, image_rgb)

        return send_file(output_path, mimetype='image/png')

def extract_features(image, model):
    image = transform(image).unsqueeze(0)  # Add batch dimension
    with torch.no_grad():
        features = model(image)
    return features.numpy().flatten()

# Run the app
if __name__ == '__main__':
    app.run(debug=True)

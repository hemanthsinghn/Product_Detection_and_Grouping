import pickle
import torch
from ultralytics import YOLO
import torchvision.models as models

# Step 1: Load the trained YOLOv8 model
yolo_model = YOLO('final_model/yolov8_sku110k.pt')

# Step 2: Load the pre-trained ResNet50 model
resnet_model = models.resnet50(pretrained=True)
resnet_model.eval()  # Set to evaluation mode

# Step 3: Save both models in a single pickle file
models_dict = {
    "yolo": yolo_model,
    "resnet": resnet_model
}

# Step 4: Save the combined models as a pickle file in the desired location
save_path = 'Product_Detection_and_Grouping.pkl'
with open(save_path, 'wb') as file:
    pickle.dump(models_dict, file)

print("Both models have been saved successfully in:", save_path)
